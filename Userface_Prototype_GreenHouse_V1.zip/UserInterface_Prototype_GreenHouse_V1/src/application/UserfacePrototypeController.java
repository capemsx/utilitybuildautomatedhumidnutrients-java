package application;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.Slider;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.web.WebView;

public class UserfacePrototypeController {

    @FXML
    private Slider WindowChangeSlider;

    @FXML
    private ProgressIndicator airHUM_Value;

    @FXML
    private ToggleButton automateProcessToggleButton;

    @FXML
    private Button cellSetting;

    @FXML
    private TabPane cell_InsightsBox;

    @FXML
    private AnchorPane changeValuesBox;

    @FXML
    private AnchorPane forecastBox;

    @FXML
    private Slider lightChangeSlider;

    @FXML
    private TextField lightChangeValue;

    @FXML
    private ProgressIndicator lightIntesityValue;

    @FXML
    private WebView liveCamera;

    @FXML
    private Tab liveTab;

    @FXML
    private AnchorPane measuedValuesBox;

    @FXML
    private AnchorPane plantCell1;

    @FXML
    private Label plantCellName;

    @FXML
    private ListView<?> plantCellsList;

    @FXML
    private TextField predictedFinishDate;

    @FXML
    private ProgressIndicator soilHUM_Value;

    @FXML
    private Tab statisticsTab;

    @FXML
    private WebView statisticsView;

    @FXML
    private Button submitChangeValues;

    @FXML
    private ProgressIndicator temperatureValue;

    @FXML
    private Tab timelineTab;

    @FXML
    private WebView timelineVideo;

    @FXML
    private TextField wantedFinishDate;

    @FXML
    private Slider waterChangeSlider;

    @FXML
    private TextField waterChangeValue;

    @FXML
    private TextField windowChangeAngle;

}
