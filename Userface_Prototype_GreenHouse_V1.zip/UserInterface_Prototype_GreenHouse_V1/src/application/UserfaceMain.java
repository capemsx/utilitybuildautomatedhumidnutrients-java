package application;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.SplitPane;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;

public class UserfaceMain extends Application
{
   Stage meineBühne;
	SplitPane meinBühnenbild;
	
	@Override
	public void start(Stage primaryStage) {
		meineBühne=primaryStage;
					
		try 
		{
		   FXMLLoader lLoader = new FXMLLoader();
		   lLoader.setLocation(UserfaceMain.class.getResource("GreenHouse_Prototyp_V-1.fxml"));
		   meinBühnenbild= (SplitPane) lLoader.load();
			
		} 
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		
		Scene lScene = new Scene(meinBühnenbild);
		meineBühne.setScene(lScene);
		meineBühne.show();
	}
	
	public static void main(String[] args) {
		launch(args);
	}

}
